-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 14, 2015 at 07:19 PM
-- Server version: 5.5.41-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cafeteria`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'hotdrink'),
(2, 'cool'),
(3, 'drinks'),
(4, 'water');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE IF NOT EXISTS `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` enum('processing','done','outfordelivery','') NOT NULL DEFAULT 'processing',
  `userid` int(11) NOT NULL,
  `note` text NOT NULL,
  `roomN` int(11) NOT NULL,
  `extN` int(11) NOT NULL,
  `action` tinyint(1) NOT NULL DEFAULT '0',
  `total` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=66 ;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `datetime`, `status`, `userid`, `note`, `roomN`, `extN`, `action`, `total`) VALUES
(40, '2015-04-14 14:38:01', 'processing', 17, '', 4123, 4123, 0, 5),
(41, '2015-04-10 13:37:47', 'processing', 19, 'sara abdallah ', 1234, 1245, 0, 10),
(42, '2015-04-10 23:04:38', 'outfordelivery', 17, '', 4123, 4123, 0, 15.5),
(43, '2015-04-10 22:23:45', 'outfordelivery', 17, '', 4123, 4123, 0, 15.5),
(44, '2015-04-10 12:06:07', 'outfordelivery', 17, '', 4123, 4123, 0, 15.5),
(45, '2015-04-10 22:23:53', 'outfordelivery', 17, '', 4123, 4123, 0, 15),
(46, '2015-04-10 22:22:04', 'processing', 21, '', 4123, 4123, 0, 15),
(48, '2015-04-11 14:31:50', 'processing', 20, '', 4123, 4123, 0, 41),
(49, '2015-04-11 19:32:26', 'outfordelivery', 17, '', 4123, 4123, 0, 13.5),
(50, '2015-04-11 19:36:20', 'outfordelivery', 17, '', 4123, 4123, 0, 5),
(51, '2015-04-12 10:36:52', 'outfordelivery', 17, '', 4123, 4123, 0, 5),
(52, '2015-04-14 14:55:27', 'processing', 18, '', 4123, 4123, 1, 12),
(53, '2015-04-12 10:36:54', 'outfordelivery', 17, '', 4123, 4123, 0, 5),
(54, '2015-04-12 10:44:35', 'outfordelivery', 17, '', 4123, 4123, 0, 5),
(55, '2015-04-12 10:44:42', 'outfordelivery', 18, '', 4123, 4123, 0, 5),
(56, '2015-04-12 10:54:11', 'outfordelivery', 18, '', 4123, 4123, 0, 5),
(57, '2015-04-12 10:54:15', 'outfordelivery', 19, '', 4123, 4123, 0, 8),
(58, '2015-04-14 14:38:26', 'processing', 17, '', 4123, 4123, 0, 18.5),
(59, '2015-04-12 10:54:06', 'outfordelivery', 17, '', 4123, 4123, 0, 9),
(60, '2015-04-12 10:54:08', 'outfordelivery', 17, '', 4123, 4123, 0, 13.5),
(61, '2015-04-12 10:54:09', 'outfordelivery', 17, '', 4123, 4123, 0, 8.5),
(62, '2015-04-12 14:09:51', 'outfordelivery', 17, '', 4123, 4123, 0, 5),
(63, '2015-04-14 14:56:20', 'processing', 18, '', 4123, 4123, 1, 6),
(64, '2015-04-12 17:43:09', 'processing', 21, '', 4123, 4123, 0, 37),
(65, '2015-04-14 15:15:13', 'processing', 18, '', 4123, 4123, 0, 3);

-- --------------------------------------------------------

--
-- Table structure for table `orderproduct`
--

CREATE TABLE IF NOT EXISTS `orderproduct` (
  `orderid` int(11) NOT NULL,
  `productid` int(11) NOT NULL,
  `amount` int(8) NOT NULL,
  PRIMARY KEY (`orderid`,`productid`),
  KEY `productid` (`productid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orderproduct`
--

INSERT INTO `orderproduct` (`orderid`, `productid`, `amount`) VALUES
(40, 5, 1),
(41, 5, 2),
(42, 5, 1),
(42, 6, 1),
(42, 7, 1),
(42, 8, 1),
(43, 5, 1),
(43, 6, 1),
(43, 7, 1),
(43, 8, 1),
(44, 5, 1),
(44, 6, 1),
(44, 7, 1),
(44, 8, 1),
(45, 5, 4),
(46, 5, 3),
(48, 5, 5),
(48, 6, 4),
(49, 5, 1),
(49, 6, 1),
(49, 7, 1),
(50, 5, 1),
(51, 5, 1),
(52, 6, 3),
(53, 5, 1),
(54, 5, 1),
(55, 5, 1),
(56, 5, 1),
(57, 6, 2),
(58, 5, 1),
(58, 6, 1),
(58, 7, 1),
(58, 8, 1),
(58, 11, 1),
(59, 5, 1),
(59, 6, 1),
(60, 5, 1),
(60, 6, 1),
(60, 7, 1),
(61, 6, 1),
(61, 7, 1),
(62, 5, 1),
(63, 11, 4),
(64, 5, 2),
(64, 6, 2),
(64, 7, 2),
(64, 8, 2),
(64, 11, 2),
(65, 11, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `price` float NOT NULL,
  `image` varchar(80) NOT NULL,
  `catid` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `deleted` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `price`, `image`, `catid`, `status`, `deleted`) VALUES
(4, 'tea', 2, '1851jpeg', 1, 1, 'yes'),
(5, 'coffee', 5, '3267png', 1, 0, ''),
(6, 'pepsi', 4, '483png', 2, 0, ''),
(7, 'sprite', 4.5, '2435png', 2, 1, ''),
(8, 'Tea', 2, '4048png', 1, 1, ''),
(9, 'Tea', 2.5, '2140png', 1, 0, 'yes'),
(10, 'nada', 5, '603png', 1, 0, 'yes'),
(11, 'coffee Mix', 3, '3483png', 1, 1, ''),
(12, 'fhgyjuk', 5, '3510png', 1, 0, ''),
(13, 'sss', 4, '2307png', 1, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` char(32) NOT NULL,
  `email` varchar(80) NOT NULL,
  `roomNo` int(10) NOT NULL,
  `ext` int(7) NOT NULL,
  `image` varchar(80) NOT NULL,
  `type` varchar(8) NOT NULL,
  `deleted` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `password`, `email`, `roomNo`, `ext`, `image`, `type`, `deleted`) VALUES
(14, 'Admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@yahoo.com', 4123, 4123, '4505jpg', 'admin', ''),
(16, 'Sara Abdallah', '5bd537fc3789b5482e4936968f0fde95', 'sara@yahoo.com', 1234, 1245, '2756jpg', 'user', 'yes'),
(17, 'Asmaa Majd', '9129fa91ab866095c0abdbff540d7a43', 'asmaa@yahoo.com', 1234, 7654, '1853jpg', 'user', ''),
(18, 'Rokia Ahmed', 'b19ba5eac94de1e5dacaf03e709efeb5', 'rokia@yahoo.com', 4567, 4567, '198jpg', 'user', ''),
(19, 'Nada Hossam', 'a77b4f006a4994d245a12247b8e4082c', 'nada@yahoo.com', 6789, 5678, '90jpg', 'user', ''),
(20, 'Dalia Hassan', '5e6e3d387a8e029ba1a6176684d524bd', 'dalia@yahoo.com', 4567, 1234, '1574jpg', 'user', ''),
(21, 'Sara Abdallah', '5bd537fc3789b5482e4936968f0fde95', 'anosh@yahoo.com', 4567, 1234, '1323jpg', 'user', ''),
(22, 'sssssssssss', 'sara', 'saraabdallah59@gmail.com', 1259, 4587, '', 'user', 'yes');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`id`);

--
-- Constraints for table `orderproduct`
--
ALTER TABLE `orderproduct`
  ADD CONSTRAINT `orderproduct_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `order` (`id`),
  ADD CONSTRAINT `orderproduct_ibfk_2` FOREIGN KEY (`productid`) REFERENCES `product` (`id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`catid`) REFERENCES `category` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
