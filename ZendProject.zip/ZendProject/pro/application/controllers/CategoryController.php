<?php

class CategoryController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
        $authorization = Zend_Auth::getInstance();

        if(!$authorization->hasIdentity() && $this->_request->getActionName() != "login" && $this->_request->getActionName() != "forgetpassword")
         {
            $this->redirect('user/login');
         }
         if($authorization->getIdentity()->id !=14)
         {
             $this->redirect('order/userorder/');
         }
    }

    public function indexAction()
    {
        // action body
    }

    public function addAction()
    {
        // action body
        $form = new Application_Form_Addcategory();
        
        // send form to view
        $this->view->form = $form;
        
        if($this->getRequest()->isPost()){
        if($form->isValid($this->getRequest()->getParams())){
            
            $data=$form->getValues(); // get data from form 
          
            $category = new Application_Model_Category(); // object from model 
            $addcategory = $category->addcategory($data); // call function to add category
            echo 'category added' ;
             
        }
    }
    }


}



