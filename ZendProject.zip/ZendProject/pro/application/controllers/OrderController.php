<?php

class OrderController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
        $authorization = Zend_Auth::getInstance();

        if(!$authorization->hasIdentity() && $this->_request->getActionName() != "login"&& $this->_request->getActionName() != "forgetpassword")
         {
            $this->redirect('user/login');
         }
         
    }

    public function indexAction()
    {
        // action body
    }

    public function adminorderAction()
    {
        // action body
        $authorization = Zend_Auth::getInstance();
        if($authorization->getIdentity()->id !=14)
         {
             $this->redirect('order/userorder/');
         }
         $product=new Application_Model_Product();
        $this->view->products=$product->availbleProducts();
        $user = new Application_Model_User();
        $this->view->users = $user->listusers();// to view all users in view
        $this->view->rooms = $user->listrooms();// to view all rooms in view
        if($this->getRequest()->isPost()){
        $productid=$this->getRequest()->getParam('productid');
        if($productid==NULL){
             echo '<script> alert("please choose products!"); </script>';
        }
        else {
        $productamount=$this->getRequest()->getParam('amount');
        $userid=  $this->getRequest()->getParam('userid');
        $note = $this->getRequest()->getParam('note');
        $room = $this->getRequest()->getParam('roomN');
        $totalPrice = $this->getRequest()->getParam('orderprice');
        // to get ext no for select room :
         $extins = $user->getExt($room);
         $extins2=array_shift($extins);
         $ext = $extins2['ext'] ;
        
        
        
        
        // to send data to model to inset order in db :
         $order = new Application_Model_Order();
        
         $data = ['userid'=>$userid,'note'=>$note,'roomN'=>$room,'extN'=>$ext,'total'=>$totalPrice];
        $add = $order->addorder($data,$productid,$productamount);
          echo '<script> alert("Order Done"); </script>';
           
        }
        }
    }

    public function userorderAction()
    {
        
         $product=new Application_Model_Product();
        $this->view->products=$product->availbleProducts();
        $user = new Application_Model_User();
        
        $this->view->rooms = $user->listrooms();// to view all rooms in view
        if($this->getRequest()->isPost()){
        $productid=$this->getRequest()->getParam('productid');
        if($productid==NULL){
         
         
            echo '<script> alert("please choose products!"); </script>';
        
        }
        else {
        $productamount=$this->getRequest()->getParam('amount');
        
        $note = $this->getRequest()->getParam('note');
        $room = $this->getRequest()->getParam('roomN');
        //echo $room;
        $totalPrice = $this->getRequest()->getParam('orderprice');
       
        // to find user id  from session : 
         $z=Zend_Auth::getInstance();
         $userid = $z->getIdentity()->id;
        
         /// to get ext no for select room :
        
        $extins = $user->getExt($room);
        $extins2=array_shift($extins);
        $ext = $extins2['ext'] ;
        
        
        // to send data to model to inset order in db :
         $order = new Application_Model_Order();
         $data = ['userid'=>$userid,'note'=>$note,'roomN'=>$room,'extN'=>$ext,'total'=>$totalPrice];
         $add = $order->addorder($data,$productid,$productamount);
          echo '<script> alert("Order Done"); </script>';
        }
        }
    }

    public function viewuserorderAction()
    {
        // action body
        
         if ($orderdate = file_get_contents("php://input")) {
            $orderdate = json_decode($orderdate);

            $auth = Zend_Auth::getInstance();
            $uid = $auth->getIdentity()->id;
            $order = new Application_Model_Order();
            $orderproduct = new Application_Model_Order2();
            $product = new Application_Model_Product();
            $resultTable = $order->selectMyOrder($uid, $orderdate);
            $idorder = [];
            foreach ($resultTable as $key => $val) {
                $idorder[] = $val['id'];
//                echo $val['id'];
            }
            $detailorder = $orderproduct->orderproduct($idorder);
            $productinfo = [];
            $amount = [];
            foreach ($detailorder as $key => $val) {

                $productinfo[] = $product->getProductById($val[0]['productid']);
                $amount[] = $val[0]['amount'];

            }
            $allinfo=[$resultTable,$amount,$productinfo];
            echo(json_encode($allinfo));

            exit() ;
            }
        
        
    }

     public function editactionAction(){
        $pid=$this->getRequest()->getParam('id');
        $order = new Application_Model_Order();
        $order->editorderaction($pid);
        $this->render("viewuserorder");
    }
    
    public function viewadminorderAction()
    {
        // action body
        $authorization = Zend_Auth::getInstance();
        if($authorization->getIdentity()->id !=14)
         {
             $this->redirect('order/userorder/');
         }
        $order = new Application_Model_Order() ;  
        $this->view->orders = $order->vieworders();
       
        
    }

    // this action to update order from deliver to out of delivery :
    public function updateadminorderAction()
    {
            $id=$this->getRequest()->getParam("id");
            if(isset($id))
            {
                $ordermodel=new Application_Model_Order();
                $ordermodel->updatorder($id);
                $this->redirect("order/viewadminorder");
             
            }
    }
    
    // this action to search by price :
    public function searchpriceAction()
    {
        if($this->getRequest()->isPost())
       
            {
                $price = $this->getRequest()->getParam("search");
                $product=new Application_Model_Product();
                $search = $product->searchByPrice($price);
                print_r($search);
               // $this->redirect("order/viewadminorder");
             
            }
        
    }
    
    
    // checks :
    public function checksformAction(){
          if($check=file_get_contents("php://input")){ 
         
                $check = json_decode($check);
                $ordermodel=new Application_Model_Order();
                $selectresult=$ordermodel->checkorder($check->startdate, $check->enddate);
                echo($res = json_encode($selectresult));
              
                exit();
 
            
         }  
   
            
    }
        public function checksuserformAction(){
          if($check=file_get_contents("php://input")){ 
         
                $check = json_decode($check);
                $ordermodel=new Application_Model_Order();
                $selectresult=$ordermodel->checkordersel($check->startdate, $check->enddate,$check->usercheckid);
                echo($res = json_encode($selectresult));
              
                exit();
 
            
         }  
   
            
    }
     public function checksdatesAction(){
          if($check=file_get_contents("php://input")){ 
                $check = json_decode($check);
                $ordermodel=new Application_Model_Order();
                $selectresult=$ordermodel->checkdates($check->startdate, $check->enddate,$check->usercheckid);
                echo($secres = json_encode($selectresult));
              
                exit();
 
            
         }  
   
            
    }
    public function checksproductAction(){
          if($check=file_get_contents("php://input")){ 
                $check = json_decode($check);
                $productmodel=new Application_Model_Product();
                $selectresult=$productmodel->checkproducts($check->ordercheckid);
                echo($thirdres = json_encode($selectresult));
              
                exit();
 
            
         } 
         
   
            
    }

    

    public function checksAction()
            
    {
        $authorization = Zend_Auth::getInstance();
        if($authorization->getIdentity()->id !=14)
         {
             $this->redirect('order/userorder/');
         }
        $user = new Application_Model_User();
        $this->view->users = $user->listusers();
             
        
       
    }
    

}











