<?php

class ProductController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
        $authorization = Zend_Auth::getInstance();

        if(!$authorization->hasIdentity() && $this->_request->getActionName() != "login" && $this->_request->getActionName() != "forgetpassword")
         {
            $this->redirect('user/login');
         }
         if($authorization->getIdentity()->id !=14)
         {
             $this->redirect('order/userorder/');
         }
    }

    public function indexAction()
    {
        // action body
    }

    public function addAction()
    {
        // action body
        $form = new Application_Form_Addproduct();
        
        // to show all category in drop down list :
            $categoryName = new Application_Model_Category();
            $categories= $categoryName->viewcategory();
            
            foreach ($categories as $value) {
                $form->getElement('catid')->addMultiOption($value['id'],$value['name']) ;
               
                
            }
            // send form to view
        $this->view->form = $form;
        if($this->getRequest()->isPost()){
        if($form->isValid($this->getRequest()->getParams())){
            
            $ext = end(explode('.', $form->getElement('image')->getValue()));
            $path = '/var/www/html/project/public/Pimages/'.rand(0, 5148).$ext ;
            $form->getElement('image')->addFilter('Rename',array('target'=> $path,'overwrite'=>true));
            $form->getElement('image')->receive();
            
            $data=$form->getValues(); // get data from form 
          
            $product = new Application_Model_Product(); // object from model 
            $addproduct = $product->addproduct($data); // call function to add product
            $this->redirect("product/view");
          
             
        }
    }
    }

    public function viewAction()
    {
        $productModel = new Application_Model_Product();
        $products = $productModel->allProducts();
        $this->view->product = $products;
    }


    public function deleteAction()
    {
        $id = $this->getRequest()->getParam('id');
        $product = new Application_Model_Product(); 
        $product->deleteproduct($id); 
        $this->redirect('Product/view');
    }
    
    
     public function statusAction()
    {
       
        $id = $this->getRequest()->getParam('id');
        $product = new Application_Model_Product(); 
        $product->statusproduct($id) ; 
        $this->redirect('Product/view');
    }
    
    
    
      public function editAction()
    {
        $id = $this->getRequest()->getParam("id");
        $productmodel = new Application_Model_Product();
        $product_data=$productmodel->getProductById($id);
        $form=new Application_Form_Addproduct();
        
        $form->removeElement('catid');
        $form->getElement('image')->setRequired(false); // if you don't choose image don't aske me to choose it
        
        $this->view->form=$form;
        
        $form->populate($product_data[0]);
        
        $this->render('add');
        
    
       if($this->getRequest()->isPost()){
       if($form->isValid($this->getRequest()->getParams())){
        if(empty($form->getValues()['image']))
           {
                 $form->removeElement('image');
                 $data1=$form->getValues(); 
                 $productedit = $productmodel->editProduct($id, $data1);
                 $this->redirect('Product/view');
            }else
                {
                 $ext = end(explode('.', $form->getElement('image')->getValue()));
                 $path = '/var/www/html/project/public/Pimages/'.rand(0, 5148).$ext ;
                 $form->getElement('image')->addFilter('Rename',array('target'=> $path,'overwrite'=>true));
                 $form->getElement('image')->receive();
                 $data1=$form->getValues(); 
                 $productedit = $productmodel->editProduct($id, $data1);
                 $this->redirect('Product/view');
                 }
            
        }
        else
        {
            echo 'form is not valid ' ;
        }
     
    }


}

}







