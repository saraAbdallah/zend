<?php

class UserController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
        $authorization = Zend_Auth::getInstance();

        if(!$authorization->hasIdentity() && $this->_request->getActionName() != "login"&& $this->_request->getActionName() != "forgetpassword")
         {
            $this->redirect('user/login');
         }
    }

    public function indexAction()
    {
        // action body
    }

    public function addAction()
    {
        // action body
        // show from to  add user 
        $authorization = Zend_Auth::getInstance();
        if($authorization->getIdentity()->id !=14)
         {
             $this->redirect('order/userorder/');
         }
        $form = new Application_Form_Adduser();
        
        // send form to view
        $this->view->form = $form;
        if($this->getRequest()->isPost()){
        if($form->isValid($this->getRequest()->getParams())){
            if($form->getElement('password')->getValue() != $form->getElement('Cpassword')->getValue())
            {
                echo 'password not match ' ;
                
            }
            
                
            else
            {
                $user = new Application_Model_User() ;
               $useremail =$user->checkEmail($form->getElement('email')->getValue());
             
               if(count($useremail)>0){
                   echo 'Email already exist' ;
               }else{
                $form->removeElement('Cpassword');
                $ext = end(explode('.', $form->getElement('image')->getValue()));
                $path = '/var/www/html/project/public/Uimages/'.rand(0, 5148).$ext ;
                $form->getElement('image')->addFilter('Rename',array('target'=> $path,'overwrite'=>true));
                $form->getElement('image')->receive();
                
                  $form->getElement('type')->setValue('user');      
                $data=$form->getValues(); // get data from form 

                $user = new Application_Model_User(); // object from model 
                $useradd = $user->adduser($data); // call function to add user
               $this->redirect("user/allusers");
               }
            }
          
           
             
        }
    }
    }

    public function loginAction()
    {
        // action body
          $auth = Zend_Auth::getInstance();
        if (($auth->hasIdentity())&&($auth->getIdentity()->type!= 'admin'))
        {
            $this->redirect('order/userorder') ;
        }
         if(($auth->hasIdentity())&&($auth->getIdentity()->type= 'admin'))
        {
            $this->redirect('order/viewadminorder') ;
        }
        $form = new Application_Form_Login() ;  // object from login form
        // send form to view
        $this->view->form = $form;
        // check if user submit :
        if($this->getRequest()->isPost()){
        if($form->isValid($this->getRequest()->getParams())){
            $email= $this->_request->getParam('email');
            $password= $this->_request->getParam('password');
            $db = Zend_Db_Table::getDefaultAdapter(); // to open connection on db
            // to compare data with data in db 
            $authAdapter = new Zend_Auth_Adapter_DbTable($db,'user' ,'email' , 'password');
            $authAdapter->setIdentity($email);
            $authAdapter->setCredential(md5($password));
            $result = $authAdapter->authenticate();
            if ($result->isValid()) 
            {
               //store data in session :

                $storage = $auth->getStorage();
                $storage->write($authAdapter->getResultRowObject(array('type' , 'name' , 'id' ,'image','deleted')));
                if(($auth->getIdentity()->type!= 'admin')&&($auth->getIdentity()->deleted!= 'yes'))
                {
                    $this->redirect('order/userorder') ;
                }
                
                elseif (($auth->getIdentity()->type!= 'admin')&&($auth->getIdentity()->deleted= 'yes'))
                {
                $this->redirect('user/login') ;
                }
                
                else
                {
                    $this->redirect('order/viewadminorder') ;
                }
                 


            }
            else
            {
                 $this->redirect('user/login') ;
            }

    
             
        }
    }


    }

    public function logoutAction()
    {
        // action body
        $auth = Zend_Auth::getInstance();
        $auth->clearIdentity(); // to destroy session
        $this->redirect('user/login') ;
    }

    public function allusersAction()
    {
        // action body
        $authorization = Zend_Auth::getInstance();
        if($authorization->getIdentity()->id !=14)
         {
             $this->redirect('order/userorder/');
         }
        $usermodel=new Application_Model_User();
        if($allusers=$usermodel->listusers())
        {
            $this->view->allusers=$allusers;
        }
    }

    public function deleteuserAction()
    {
        // action body
        $authorization = Zend_Auth::getInstance();
        if($authorization->getIdentity()->id !=14)
         {
             $this->redirect('order/userorder/');
         }
        $id=$this->getRequest()->getParam("id");
         if(isset($id))
         {
            $usermodel=new Application_Model_User();
            $usermodel->deleteuser($id);
            $this->redirect("user/allusers");
             
         }
    }

     public function edituserAction()
    {
        // action body
         $authorization = Zend_Auth::getInstance();
        if($authorization->getIdentity()->id !=14)
         {
             $this->redirect('order/userorder/');
         }
        $usermodel=new Application_Model_User();
        $usersdata=$usermodel->getuserbyid($this->getRequest()->getParam('id'));
        $userid=$this->getRequest()->getParam('id');
        $form=new Application_Form_Adduser();
        $form->populate($usersdata[0]);
        $form->getElement('password')->setRequired(false);
        $form->getElement('image')->setRequired(false);
        $form->getElement('Cpassword')->setRequired(false);
        $this->view->form=$form;
        $this->render("add");
        if($this->getRequest()->isPost())
        {
            if($form->isValid($this->getRequest()->getParams()))
            {
                
                if(empty($form->getValues()['password']))
                {
                    $form->removeElement('password');
                    $form->removeElement('Cpassword');
                    if(empty($form->getValues()['image']))
                    {
                        $form->removeElement('image');
                        


                                              if($usermodel->edituser($form->getValues(),$userid))
                                              {
                                                  $this->redirect("user/allusers");
                                              }
                                              else{
                                                  $this->redirect("user/edituser");
                                              }

                    }
                    else {
                        $ext = end(explode('.', $form->getElement('image')->getValue()));
                        $path = '/var/www/html/project/public/Uimages/'.rand(0, 5148).$ext ;
                        $form->getElement('image')->addFilter('Rename',array('target'=> $path,'overwrite'=>true));
                        $form->getElement('image')->receive();
                         if($usermodel->edituser($form->getValues(),$userid))
                          {
                               $this->redirect("user/allusers");
                          }
                          else{
                               $this->redirect("user/edituser");   
                          }
                 }
                    
                          
                }
                
                else{
                    if($form->getElement('password')->getValue() != $form->getElement('Cpassword')->getValue())
                    {
                        echo 'password not match ' ;

                    }
                    else {
                      if(empty($form->getValues()['image']))
                        {
                        $form->removeElement('image');
                        $form->getValues()['password']=md5($form->getValues()['password']);
                                           $form->removeElement('Cpassword');


                                              if($usermodel->edituser($form->getValues(),$userid))
                                              {
                                                  $this->redirect("user/allusers");
                                              }
                                              else{
                                                  $this->redirect("user/edituser");
                                              }

                        }
                    else{
                        $ext = end(explode('.', $form->getElement('image')->getValue()));
                        $path = '/var/www/html/project/public/Uimages/'.rand(0, 5148).$ext ;
                        $form->getElement('image')->addFilter('Rename',array('target'=> $path,'overwrite'=>true));
                        $form->getElement('image')->receive();
                        $form->getValues()['password']=md5($form->getValues()['password']);
                        $form->removeElement('Cpassword');


                                              if($usermodel->edituser($form->getValues(),$userid))
                                              {
                                                  $this->redirect("user/allusers");
                                              }
                                              else{
                                                  $this->redirect("user/edituser");
                                              }
                    }
                                           
                
                        }
                    }
                
            }
            else {
                echo 'form is not valid ' ;
             }
        }
    
        
    }
    public function forgetpasswordAction()
    {
        // action body
        $form = new Application_Form_Login() ;  // object from login form
        $form->removeElement('password');
        $form->getElement('Login')->setLabel('send');
        $this->view->form = $form;
        if($this->getRequest()->isPost()){
            if($form->isValid($this->getRequest()->getParams())){
                $email= $this->_request->getParam('email');
                $usermodel=new Application_Model_User();
                
                if($userid=$usermodel->checkuserEmail($email))
                {
                    
                       $newpassword = substr(hash('sha512',rand()),0,8);

                        
                            $smtpoptions=array(
                            'auth'=>'login',
                            'username'=>'asmaamohamedmagdhelali@gmail.com',
                            'password'=>'asmaa2961991',
                            'ssl'=>'tls',
                            'port'=>587
                        );
                        $mailtransport=new Zend_Mail_Transport_Smtp('smtp.gmail.com',$smtpoptions);
                        $mail = new Zend_Mail();
                        $mail->addTo($email,'to You');
                        $mail->setSubject('Hellow User');
                        $mail->setBodyText('message from our cafeteria your new password is'.$newpassword);
                        $mail->setFrom('asmaamohamedmagdhelali@gmail.com', 'Cafeteria of Sara');

                        //Send it!
                        $sent = true;
                        try {
                            $mail->send($mailtransport);
                        } catch (Exception $e){
                            echo $e;
                            $sent = false;
                        }

                        //Do stuff (display error message, log it, redirect user, etc)
                        if($sent){
                                if($usermodel->updateuseremail(md5($newpassword), $userid[0]['id']))
                                {
                                    echo 'successfully sent please check your Email';
                                }
                                else {
                                     echo 'error in server';
                                }
                                
                            
                        } else {
                            echo 'failed sending to your email please check your settings';
                        }
                    
                        
                    }
                    
                    
                }
                else {
                    echo 'This email is not Existed in my database';
                }
            }
    }


}









