
<?php

class Application_Form_Addcategory extends Zend_Form
{

    public function init()
    {
        $name = new Zend_Form_Element_Text("name") ;
        $name->setLabel("Category Name ") ;
        $name->setRequired();
        $name->addFilter(new Zend_Filter_StripTags());
        
        // submit button :
        $submit = new Zend_Form_Element_Submit("save");
        //reset button :
        $reset = new Zend_Form_Element_Reset("reset") ;
        // add elements to form :
        $this->addElements(array($name, $submit,$reset));
    }


}

