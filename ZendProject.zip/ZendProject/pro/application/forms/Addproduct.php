
<?php

class Application_Form_Addproduct extends Zend_Form
{

    public function init()
    {
        /* Form Elements & Other Definitions Here ... */
        // product name :
        $name = new Zend_Form_Element_Text("name") ;
        $name->setLabel("Product ") ;
        $name->setRequired();
        $name->addFilter(new Zend_Filter_StripTags());
        
        // product price :
        $price = new Zend_Form_Element_Text("price") ;
        $price->addValidator(new Zend_Validate_Float());
        
        $price->addValidator(new Zend_Validate_Between(array('min'=>1.5,'max'=>10)));       
      
        $price->setLabel(" Price ");
        $price->setRequired();
       
       
        
        
        //product category :
        $catid = new Zend_Form_Element_Select("catid");
        
        $catid->setLabel("category ");
        $catid->setRequired();
        
        
        // product picture :
        $image = new Zend_Form_Element_File("image") ;
        $image->setLabel("ProductPicture");
        $image->addValidator(new Zend_Validate_File_Extension(('jpg,png,jpeg')));
        $image->setValueDisabled(true);
        $image->addValidator('Size', false, 102400) ;
        $image->setMaxFileSize(102400);
        $image->setRequired();
        
        // submit button :
        $submit = new Zend_Form_Element_Submit("save");
        //reset button :
        $reset = new Zend_Form_Element_Reset("reset") ;
        
        // hidden field for id :
        //$id = new Zend_Form_Element_Hidden("id");
        // add elements to form :
        $this->addElements(array($name, $price, $catid, $image,$submit,$reset));
    }


}

