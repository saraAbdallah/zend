<?php

class Application_Form_Adduser extends Zend_Form
{

    public function init()
    {
        /* Form Elements & Other Definitions Here ... */
        $name = new Zend_Form_Element_Text("name") ;
        $name->setLabel("Name ") ;
        $name->setRequired();
        
        //$name->setAttrib('id', l)
        $name->addFilter(new Zend_Filter_StripTags());
        
        $type = new Zend_Form_Element_Hidden("type") ;
        
        
        // user email field :
        $email = new Zend_Form_Element_Text("email") ;
        $email->setLabel(" Email ");
        $email->setRequired();
        $email->addValidator(new Zend_Validate_EmailAddress);
       
        
        
        //user password field :
        $password = new Zend_Form_Element_Password("password");
        $password->setLabel("Password ");
        $password->setRequired();
        
        // confirm password :
        $Cpassword = new Zend_Form_Element_Password("Cpassword");
        $Cpassword->setLabel("Confirm Password ");
        $password->setRequired();
        
        
        // Room number :
        $room = new Zend_Form_Element_Text("roomNo") ;
        $room->addValidator(new Zend_Validate_Int());
        $room->addValidator(new Zend_Validate_StringLength(array('min'=>4,'max'=>4)));
        $room->setLabel("Room No");
        $password->setRequired();
        
        // extension number :
        $ext = new Zend_Form_Element_Text("ext") ;
        $ext->addValidator(new Zend_Validate_Int());
        $ext->addValidator(new Zend_Validate_StringLength(array('min'=>4,'max'=>4)));
        $ext->setLabel("Ext");
        $ext->setRequired();
        
        // profile picture :
        $image = new Zend_Form_Element_File("image") ;
        $image->setLabel("Profile Picture");
        $image->addValidator(new Zend_Validate_File_Extension(('jpg,png,jpeg')));
        $image->setValueDisabled(true);
        $image->addValidator('Size', false, 102400) ;
        $image->setMaxFileSize(102400);
        $image->setRequired();
        
        // submit button :
        $submit = new Zend_Form_Element_Submit("save");
        //reset button :
        $reset = new Zend_Form_Element_Reset("reset") ;
        
        // hidden field for id :
        //$id = new Zend_Form_Element_Hidden("id");
        // add elements to form :
        $this->addElements(array($name,$type, $email, $password,$Cpassword,$room,$ext,$image,$submit,$reset));
    }


}

