<?php

class Application_Form_Adminorder extends Zend_Form
{

    public function init()
    {
        /* Form Elements & Other Definitions Here ... */
        $userid = new Zend_Form_Element_Select('userid');
        $userid->setLabel('Add To User');
        $userid->setRequired();
        
        
        
        $this->addElement($userid);
        
    }


}

