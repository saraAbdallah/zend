<?php

class Application_Form_Login extends Zend_Form
{

    public function init()
    {
        /* Form Elements & Other Definitions Here ... */
        
        
        
        // user email field :
        $email = new Zend_Form_Element_Text("email") ;
        $email->setLabel("Email");
        $email->setRequired();
        
        //user password field :
        $password = new Zend_Form_Element_Password("password");
        $password->setLabel("Password");
        $password->setRequired();
        
        // submit button :
        $submit = new Zend_Form_Element_Submit("Login");
        
       
        // add elements to form :
        $this->addElements(array($email, $password,$submit));
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }


}

