<?php

class Application_Model_Category  extends Zend_Db_Table_Abstract
{
    protected  $_name = "category" ; // table name 
    
    //function to add category:
    function  addcategory($data)
    {   
        return $this->insert($data);
        
    }
    
    // function to view all categories :
    function viewcategory()
    {
        return $this->fetchAll()->toArray();
    }

}

