<?php

class Application_Model_Order extends Zend_Db_Table_Abstract
{
    protected  $_name = "order" ; // table name 
    
    // function to add order :
    function addorder($data,$prodid,$amount)
    {
         
        $orderid = $this->insert($data);
        $ordermodel = new Application_Model_Order2();
        return $ordermodel->add($orderid, $prodid, $amount);
        
       
    }
    
    // function to view all orders :
    function vieworders()
    {
        $result = $this->select()->from(array('order'),array('id','datetime','roomN','extN','total'))->join(array('user'),'user.id = order.userid',array('username'=>'name'))->join(array('orderproduct'),'order.id = orderproduct.orderid',array('amount'))->join(array('product'),'product.id = orderproduct.productid',array('productname'=>'name','price','image'))->where('order.status=?','processing')->where('order.action=?',0)->where('product.status!=?','yes');
        return $this->fetchAll($result->setIntegrityCheck(false))->toArray();
        
    }
    
    // function to update order from deliver to out of delivery :
    function updatorder($id)
    {
        $data['status'] = 'outfordelivery';
        return $this->update($data, "id=".$id) ;
    }
    
    // functions used in check page:
      function  checkorder($start,$end)
    {
        $result= $this->select()->from(array('order'), array('total' => 'SUM(total)','userid' => 'userid'))
                ->join(array('user'),'user.id = order.userid',array('name'))
                ->where("datetime between '".$start."' and '".$end."'")
                ->group('name') ;
        return $this->fetchAll($result->setIntegrityCheck(false))->toArray();
      
    }
    function  checkordersel($start,$end,$userid)
    {
        $result= $this->select()->from(array('order'), array('total' => 'SUM(total)'))
                ->join(array('user'),'user.id = order.userid',array('name'))
                ->where('order.datetime >= ?',$start,'order.datatime <= ? ',$end)
                ->where('order.userid=?',$userid)
                ->group('name') ;
        return $this->fetchAll($result->setIntegrityCheck(false))->toArray();
      
    }
    function checkdates($start,$end,$userid) {
        $result = $this->select()->from( 'order',array('id','datetime', 'total'))
                ->where("datetime between '".$start."' and '".$end."'")
                ->where('userid=?',$userid);
       
        return $this->fetchAll($result)->toArray();
    }
    
   
    function selectMyOrder($uid,$orderdate){
        
        return $this->fetchAll($this->select()->from('order', array('id','datetime','status','total','action'))
                ->where('userid=?',$uid)->where('datetime >= ?',$orderdate->sdate)
                ->where('datetime <= ?',$orderdate->edate))->toArray() ;
    }
    
    function editorderaction($id){
        $data['action'] = 1;
        $this->update($data,"id=".$id);
               
    }
   
    

    
    

}

