<?php

class Application_Model_Order2 extends Zend_Db_Table_Abstract

{
    protected  $_name = "orderproduct" ; // table name 
    
    function add($orderid,$prodid,$amount)
    {
        
        for ($index = 0; $index < count($prodid); $index++) {
            $this->insert(array('orderid'=>$orderid,'productid'=>$prodid[$index],'amount'=>$amount[$index])) ;
            
        }
        return TRUE;
    }
    
    function orderproduct($id){
         $result=[];
         foreach ($id as $val){
              $result[]=$this->fetchAll($this->select()
                ->from('orderproduct',array('orderid','productid','amount'))
                ->where('orderid=?',$val))->toArray();
         }
         return $result;
    }
    


}

