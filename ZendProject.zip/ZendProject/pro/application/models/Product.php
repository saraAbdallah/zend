<?php

class Application_Model_Product extends Zend_Db_Table_Abstract
{
     protected  $_name = "product" ; // table name
     
     // function to add product :
    
    function  addproduct($data)
    {   
        return $this->insert($data);
        
    }
    
    // to view all products availble and unavailble for admin :
    function allProducts()
    {
        return $this->fetchAll($this->select()->where('deleted!=?','yes'))->toArray();
    
        
    }
    // to view all product availble only for user :
    function availbleProducts()
    {
        
        return $this->fetchAll($this->select()->where('deleted!=?','yes')->where('status=?','1'))->toArray();
        
    }
    
    
    
    function deleteproduct($id)
    {
        $data['deleted'] = 'yes';
        $data['status'] = 0 ;
        return $this->update($data, "id=".$id) ; 
    }
    
    function statusproduct($id)
    {
       
        if($product=$this->getProductById($id))
        {
            if($product[0]['status']==0)
            {
               // return $this->update("status=1", "id=$id"); 
                return $this->update(array('status'=>1), "id=".$id);
    
            }
            
            else 
            {
              return $this->update(array('status'=>0), "id=".$id);

            }
        }
        

     }
    
    function getProductById($id)
    {
       return $this->find($id)->toArray();
    }
     
    function editProduct($id, $data1)
    {
        
        $this->update($data1, "id=$id");
    }
    
    // function to search in products :
    function searchByPrice($price)
    {
        return $this->fetchAll($this->select()->where('price=?',$price))->toArray();
    
    }
    
    // function do check page :
  
     function checkproducts($orderid) {
       $result= $this->select()->from(array('product'), array('name','price','image'))
                ->join(array('orderproduct'),'product.id = orderproduct.productid',array('amount'))
                ->where('orderproduct.orderid=?',$orderid)
                ->setIntegrityCheck(false);
       
        return $this->fetchAll($result)->toArray();
    }

    
 // function to view user order :
    function selectMyOrder($uid,$orderdate){
        
        return $this->fetchAll($this->select()->from('order', array('id','datetime','status','total','action'))
                ->where('userid=?',$uid)->where('datetime >= ?',$orderdate->sdate)
                ->where('datetime <= ?',$orderdate->edate))->toArray() ;
    }


}

