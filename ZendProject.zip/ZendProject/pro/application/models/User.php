<?php

class Application_Model_User extends Zend_Db_Table_Abstract
{
    protected  $_name = "user" ; // table name
    
    // function to add user :
    
    function  adduser($data)
    {   
        $data['password'] = md5($data['password']);
        return $this->insert($data);
        
    }
    // to check email ecist in db or not and return with id 'forget password' :
    function  checkuserEmail($email)
    {
        return $this->fetchAll($this->select()->from('user', array('id'))->where('email=?',$email))->toArray() ;
    }
    // to update with new password 'forget password' :
    function  updateuseremail($newpassword,$id)
    {
        return $this->update(array('password'=>$newpassword),"id=".$id);
    }
    // function to check if email is found or not :
    function  checkEmail($email)
    {
        return $this->fetchAll($this->select()->where('email=?',$email))->toArray() ;
    }
    // function to get ext for spacific room:
    function  getExt($room)
    {
        return $this->fetchAll($this->select('ext')->where('roomNo=?',$room))->toArray() ;
        
                
    }
    
    
     function listusers()
    {
        return $this->fetchAll($this->select()->where('type=?','user')->where('deleted!=?','yes'))->toArray();
        
    }
    
    function listrooms()
    {
        return $this->fetchAll($this->select('roomNo'))->toArray();
    }
    function deleteuser($id)
    {
        $data['deleted'] = 'yes';
        return $this->update($data, "id=".$id) ;
        
    }
    function edituser($data,$id)
    {
        return $this->update($data,"id=".$id);
    }
    function getuserbyid($id)
    {
        return $this->find($id)->toArray();
    }

}

